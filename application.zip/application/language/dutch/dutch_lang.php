<?php 

// LOGIN
$lang['login_word_text_01']		=		'Login to your account';
$lang['login_word_text_02']		=		'Enter your credentials below';
$lang['login_word_text_03']		=		'Your account has been activated.  Please login to continue';
$lang['login_word_text_04']		=		'Invalid confirm key or account already activated.';
$lang['login_word_text_05']		=		'Email Address';
$lang['login_word_text_06']		=		'Password';
$lang['login_word_text_07']		=		'Remember';
$lang['login_word_text_08']		=		'Forgot password?';
$lang['login_word_text_09']		=		'Sign in';
$lang['login_word_text_10']		=		'Create an Account';

// For Heemah
$lang['english001'] = "Yes, the partnership took place";
$lang['english002'] = "No . I want to close the ad";