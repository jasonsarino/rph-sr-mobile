<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-23 01:38:56 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 01:38:56 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 01:38:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 01:38:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-23 01:38:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 01:38:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-23 01:39:07 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 01:39:09 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 01:39:12 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 01:39:12 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 01:39:13 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 01:39:13 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 01:39:15 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 01:40:55 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 01:40:56 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 01:47:21 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 01:47:26 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 01:47:39 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:28:46 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:28:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:28:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:28:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-23 23:28:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:28:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-23 23:29:09 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:29:33 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:29:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:30:39 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:30:45 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:34:25 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:34:25 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:34:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-23 23:34:25 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:34:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-23 23:34:34 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:34:36 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:34:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:34:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:34:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:34:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-23 23:34:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:34:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-23 23:35:26 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:35:26 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:35:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-23 23:35:26 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:35:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-23 23:35:30 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:35:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:35:51 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:35:53 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:35:53 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:35:53 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:35:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-23 23:36:23 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:36:23 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:36:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-23 23:36:27 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:36:30 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:36:31 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:36:31 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:36:32 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:36:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-23 23:36:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:38:33 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:38:39 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:40:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:47:44 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:47:44 --> Severity: error --> Exception: syntax error, unexpected '$log' (T_VARIABLE), expecting ')' X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Login.php 65
ERROR - 2021-10-23 23:48:15 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:48:50 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:49:27 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:49:41 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:50:19 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:51:05 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:51:18 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:51:24 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:51:51 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:52:12 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:52:46 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:53:01 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:54:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:56:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:56:25 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:57:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-23 23:57:35 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ']' X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Login.php 79
ERROR - 2021-10-23 23:58:14 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
