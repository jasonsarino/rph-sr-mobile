<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-26 04:27:08 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:27:40 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:27:40 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 58
ERROR - 2021-10-26 04:28:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:28:27 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:29:46 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:30:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:30:13 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:30:18 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:32:11 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:32:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:34:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:34:12 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:37:18 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:38:19 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 08:08:19 --> Severity: Notice --> Undefined offset: 0 X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 46
ERROR - 2021-10-26 08:08:19 --> Severity: Warning --> Invalid argument supplied for foreach() X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 46
ERROR - 2021-10-26 04:38:34 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Undefined variable: user X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 46
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 46
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Undefined variable: user X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 47
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Trying to get property 'firstname' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 47
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Undefined variable: user X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 48
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Trying to get property 'lastname' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 48
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Undefined variable: user X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 49
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Trying to get property 'email' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 49
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Undefined variable: user X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 50
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Trying to get property 'piid' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 50
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Undefined variable: user X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 51
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Trying to get property 'division_id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 51
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Undefined variable: user X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 52
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Trying to get property 'dob' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 52
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Undefined variable: user X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 53
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Trying to get property 'address' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 53
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Undefined variable: user X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 54
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Trying to get property 'accre_number' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 54
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Undefined variable: user X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 55
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Trying to get property 'accre_exp_date' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 55
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Undefined variable: user X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 56
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Trying to get property 'dhsud_number' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 56
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Undefined variable: user X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 57
ERROR - 2021-10-26 08:08:34 --> Severity: Notice --> Trying to get property 'designated_broker' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 57
ERROR - 2021-10-26 08:08:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at X:\xampp\htdocs\rcd\rph-admin\system\core\Exceptions.php:271) X:\xampp\htdocs\rcd\rph-admin\application\libraries\API_Controller.php 530
ERROR - 2021-10-26 08:08:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at X:\xampp\htdocs\rcd\rph-admin\system\core\Exceptions.php:271) X:\xampp\htdocs\rcd\rph-admin\application\libraries\API_Controller.php 531
ERROR - 2021-10-26 04:38:51 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:39:30 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:39:55 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:40:02 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:40:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:40:11 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:41:25 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:41:32 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:42:24 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:48:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:50:32 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:50:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:50:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 04:50:44 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:52:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:52:19 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:53:23 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 08:23:23 --> Severity: Notice --> Undefined property: stdClass::$position X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Users.php 51
ERROR - 2021-10-26 04:53:37 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:54:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:54:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:55:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:56:24 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:56:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 04:57:33 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 05:18:08 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 05:19:29 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 05:19:29 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 05:40:28 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 15:42:59 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 15:43:14 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-26 15:43:18 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
