<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-21 00:56:37 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 00:56:37 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 00:56:39 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 00:56:39 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 00:56:39 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 00:56:45 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 00:57:01 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 00:57:01 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 00:57:01 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 00:57:03 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 00:57:03 --> 404 Page Not Found: Manage_division/add
ERROR - 2021-10-21 00:57:50 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 00:57:50 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 00:57:51 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 00:57:55 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 06:57:55 --> Query error: Unknown column 'company_id' in 'where clause' - Invalid query: SELECT * FROM divisions WHERE `company_id` = '1' AND division =  '1234567890'
ERROR - 2021-10-21 00:58:33 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 00:58:33 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 00:58:33 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 00:58:39 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 00:58:41 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 00:58:41 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 00:58:50 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 00:58:56 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 00:59:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 00:59:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:01:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:01:36 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:01:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 07:01:52 --> Severity: Warning --> require_once(X:\xampp\htdocs\rcd\rph-admin\application\views/manage_divisions/edit.php): failed to open stream: No such file or directory X:\xampp\htdocs\rcd\rph-admin\application\views\page.php 98
ERROR - 2021-10-21 07:01:52 --> Severity: Compile Error --> require_once(): Failed opening required 'X:\xampp\htdocs\rcd\rph-admin\application\views/manage_divisions/edit.php' (include_path='X:\xampp\php\PEAR') X:\xampp\htdocs\rcd\rph-admin\application\views\page.php 98
ERROR - 2021-10-21 01:03:43 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 07:03:43 --> Severity: Notice --> Undefined variable: projectList X:\xampp\htdocs\rcd\rph-admin\application\views\manage_divisions\edit.php 56
ERROR - 2021-10-21 01:04:07 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:04:10 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:04:12 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:04:12 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 01:04:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:04:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:04:16 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 01:04:23 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:04:38 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:04:38 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:04:38 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 01:04:40 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:06:14 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:06:14 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:06:14 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 01:06:17 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 07:06:17 --> Query error: Unknown column 'developer' in 'field list' - Invalid query: UPDATE `divisions` SET `developer` = NULL
WHERE `id` = '1'
ERROR - 2021-10-21 01:06:44 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:06:44 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:06:44 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 01:06:48 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:06:50 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:06:50 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:06:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:06:55 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:06:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:06:58 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:07:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 07:07:00 --> Severity: Notice --> Undefined variable: data X:\xampp\htdocs\rcd\rph-admin\application\libraries\Bims.php 67
ERROR - 2021-10-21 07:07:00 --> Severity: Notice --> Trying to access array offset on value of type null X:\xampp\htdocs\rcd\rph-admin\application\controllers\General.php 331
ERROR - 2021-10-21 07:07:00 --> Severity: Notice --> Trying to access array offset on value of type null X:\xampp\htdocs\rcd\rph-admin\application\controllers\General.php 332
ERROR - 2021-10-21 07:07:00 --> Query error: Column 'module' cannot be null - Invalid query: INSERT INTO `activity_log` (`user_id`, `company_id`, `module`, `event`, `ipaddress`, `log_description`) VALUES ('7', '1', NULL, 'DELETE', '127.0.0.1', ' with id#1 has been deleted.')
ERROR - 2021-10-21 01:07:02 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:07:02 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:08:27 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:08:28 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:08:30 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:08:32 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:08:34 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:08:34 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:08:36 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:08:38 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:08:40 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:08:40 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:08:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:08:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:08:44 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:09:17 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:09:19 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:09:19 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:18:41 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:18:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:18:43 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:18:43 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:19:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:19:55 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:21:21 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:21:21 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:21:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:22:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:22:53 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:22:55 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:22:55 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:28:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:28:59 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:29:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:29:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:29:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 07:29:06 --> Severity: Warning --> require_once(X:\xampp\htdocs\rcd\rph-admin\application\views/manage_positions/edit.php): failed to open stream: No such file or directory X:\xampp\htdocs\rcd\rph-admin\application\views\page.php 98
ERROR - 2021-10-21 07:29:06 --> Severity: Compile Error --> require_once(): Failed opening required 'X:\xampp\htdocs\rcd\rph-admin\application\views/manage_positions/edit.php' (include_path='X:\xampp\php\PEAR') X:\xampp\htdocs\rcd\rph-admin\application\views\page.php 98
ERROR - 2021-10-21 01:30:08 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:30:56 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:30:58 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:31:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:31:01 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:31:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 07:31:04 --> Severity: Notice --> Undefined variable: data X:\xampp\htdocs\rcd\rph-admin\application\libraries\Bims.php 69
ERROR - 2021-10-21 07:31:04 --> Severity: Notice --> Trying to access array offset on value of type null X:\xampp\htdocs\rcd\rph-admin\application\controllers\General.php 331
ERROR - 2021-10-21 07:31:04 --> Severity: Notice --> Trying to access array offset on value of type null X:\xampp\htdocs\rcd\rph-admin\application\controllers\General.php 332
ERROR - 2021-10-21 07:31:04 --> Query error: Column 'module' cannot be null - Invalid query: INSERT INTO `activity_log` (`user_id`, `company_id`, `module`, `event`, `ipaddress`, `log_description`) VALUES ('7', '1', NULL, 'DELETE', '127.0.0.1', ' with id#1 has been deleted.')
ERROR - 2021-10-21 01:31:08 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:31:08 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:31:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:31:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:31:36 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:31:40 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:31:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:31:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:31:48 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:31:51 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:31:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:31:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:31:56 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:32:03 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:32:05 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:32:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:32:08 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:32:09 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:32:11 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:32:12 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:32:15 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:32:15 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:32:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 01:32:17 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 05:24:48 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 05:24:48 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 05:24:48 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 05:24:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-21 05:24:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 05:24:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-21 05:24:55 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 05:24:58 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 06:02:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 06:02:51 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 06:02:51 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 06:02:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 06:02:55 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 06:02:56 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 06:51:53 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 06:51:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 06:51:56 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 06:51:56 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 06:51:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 06:51:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 06:51:58 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 06:51:58 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 06:52:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:24:14 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:24:14 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:24:15 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:24:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-21 09:24:15 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:24:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-21 09:24:21 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:24:24 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:24:31 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:24:31 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:24:38 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:24:38 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:26:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:26:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:26:58 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:26:58 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:26:59 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:26:59 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:27:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:27:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:27:03 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:27:03 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:27:11 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:27:11 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:27:15 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:27:15 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:27:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:27:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:27:51 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:28:01 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:28:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:28:13 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:28:13 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:28:25 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:28:32 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:28:32 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:28:34 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:28:56 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:29:30 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:31:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:31:21 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:31:31 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:31:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:32:24 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:33:23 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:33:26 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:33:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:34:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:34:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:35:10 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:36:09 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:37:33 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:37:33 --> Severity: error --> Exception: Call to undefined method Position_model::getData() X:\xampp\htdocs\rcd\rph-admin\application\controllers\Manage_users.php 274
ERROR - 2021-10-21 09:37:50 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:38:28 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:39:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:39:13 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:39:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:40:58 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:40:59 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:41:03 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:41:09 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:41:10 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:41:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:41:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:41:52 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 09:42:44 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:42:44 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:42:44 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 09:44:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 09:44:21 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 10:00:19 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 10:06:24 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 10:06:25 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 10:07:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 10:07:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 10:07:21 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 10:09:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 10:09:34 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 10:10:08 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 10:11:12 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 10:12:07 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 10:16:33 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 10:16:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 10:23:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 10:25:10 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 10:26:07 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:39:58 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:39:58 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:39:59 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:39:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-21 12:39:59 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:39:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-21 12:40:05 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:40:07 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:41:38 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:46:20 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:46:50 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:46:50 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 12:47:48 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:47:48 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:47:48 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 12:48:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:48:45 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:48:45 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:48:45 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 12:48:45 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:49:02 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:49:40 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:49:45 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:49:48 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 12:49:48 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:01:34 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:01:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:02:02 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:02:02 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:02:03 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:03:05 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:03:08 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:03:09 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:03:19 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:03:39 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:04:14 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:04:26 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:04:32 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:05:15 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:06:59 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:07:27 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:07:39 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:07:44 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:07:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:07:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:08:15 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:08:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:09:01 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:10:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:11:03 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:13:59 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:22:20 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:25:13 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:26:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:26:25 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:26:25 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 13:26:27 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:26:27 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:26:27 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 13:27:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:27:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:27:00 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 13:27:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:27:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:27:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 13:28:07 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:28:07 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:28:07 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 13:29:43 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:29:43 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:29:43 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-21 13:33:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:34:51 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:34:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:34:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:35:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:37:01 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:37:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:38:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:38:17 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:39:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 13:40:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:12:21 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:12:21 --> Severity: Compile Error --> Cannot redeclare Manage_users::validate_piid() X:\xampp\htdocs\rcd\rph-admin\application\controllers\Manage_users.php 423
ERROR - 2021-10-21 14:12:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:12:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 14:13:09 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:13:12 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:13:13 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:13:13 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:13:13 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:13:14 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:13:15 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:13:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:13:17 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:13:18 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:07 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:07 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:07 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:08 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:08 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:10 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:11 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:20 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:21 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:21 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:25 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:25 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:26 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:27 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:29 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:30 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:46 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:46 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:46 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:14:48 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:17:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:17:08 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:17:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:19:05 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:19:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:19:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:19:15 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:19:15 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:19:27 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:30:07 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:30:11 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:30:11 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:30:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:32:13 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 20:32:13 --> Severity: Notice --> Undefined property: stdClass::$piid X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 38
ERROR - 2021-10-21 14:46:18 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 20:46:18 --> Severity: Notice --> Undefined property: stdClass::$piid X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 38
ERROR - 2021-10-21 20:46:18 --> Severity: Notice --> Undefined variable: position_list X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 74
ERROR - 2021-10-21 20:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 74
ERROR - 2021-10-21 20:46:18 --> Severity: Notice --> Undefined variable: division_list X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 111
ERROR - 2021-10-21 20:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 111
ERROR - 2021-10-21 14:46:39 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 20:46:39 --> Severity: Notice --> Undefined variable: position_list X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 74
ERROR - 2021-10-21 20:46:39 --> Severity: Warning --> Invalid argument supplied for foreach() X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 74
ERROR - 2021-10-21 20:46:39 --> Severity: Notice --> Undefined variable: division_list X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 111
ERROR - 2021-10-21 20:46:39 --> Severity: Warning --> Invalid argument supplied for foreach() X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 111
ERROR - 2021-10-21 14:47:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 20:47:49 --> Severity: Notice --> Undefined variable: position_list X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 74
ERROR - 2021-10-21 20:47:49 --> Severity: Warning --> Invalid argument supplied for foreach() X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 74
ERROR - 2021-10-21 20:47:49 --> Severity: Notice --> Undefined variable: division_list X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 111
ERROR - 2021-10-21 20:47:49 --> Severity: Warning --> Invalid argument supplied for foreach() X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 111
ERROR - 2021-10-21 14:48:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 20:48:06 --> Severity: Notice --> Undefined variable: position_list X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 74
ERROR - 2021-10-21 20:48:06 --> Severity: Warning --> Invalid argument supplied for foreach() X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 74
ERROR - 2021-10-21 20:48:06 --> Severity: Notice --> Undefined variable: division_list X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 111
ERROR - 2021-10-21 20:48:06 --> Severity: Warning --> Invalid argument supplied for foreach() X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 111
ERROR - 2021-10-21 14:48:14 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 20:48:14 --> Severity: Notice --> Undefined variable: position_list X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 74
ERROR - 2021-10-21 20:48:14 --> Severity: Warning --> Invalid argument supplied for foreach() X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 74
ERROR - 2021-10-21 20:48:14 --> Severity: Notice --> Undefined variable: division_list X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 111
ERROR - 2021-10-21 20:48:14 --> Severity: Warning --> Invalid argument supplied for foreach() X:\xampp\htdocs\rcd\rph-admin\application\views\manage_users\edit.php 111
ERROR - 2021-10-21 14:48:50 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:49:38 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:49:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:49:59 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:50:09 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:50:20 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:51:03 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:52:03 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:52:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:52:05 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:52:34 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:52:37 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:52:37 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:52:40 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:52:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:53:19 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:53:44 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:54:31 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:54:40 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:55:02 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:55:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:55:28 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:55:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:56:09 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:56:11 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:56:11 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:33 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:37 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:38 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:40 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:41 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:41 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:41 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:41 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:43 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:44 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:45 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:46 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:48 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:53 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:57:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 14:59:55 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:02 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:08 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:08 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:13 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:14 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:19 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:19 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:20 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:23 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:23 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:26 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:26 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:30 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:31 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:31 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:37 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:37 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:43 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:44 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:45 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:50 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:53 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:53 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:53 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:00:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:01:09 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:01:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:01:29 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:01:34 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:01:41 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:01:43 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:01:43 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:01:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:01:50 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:01:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:01:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:02:11 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:02:11 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:02:15 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:02:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:02:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:02:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:02:17 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:02:36 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:02:39 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-21 15:02:39 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
