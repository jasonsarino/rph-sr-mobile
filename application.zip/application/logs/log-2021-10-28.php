<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-28 02:47:46 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 02:47:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 02:47:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 02:47:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-28 02:47:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 02:47:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-28 02:48:27 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 02:48:29 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 02:48:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:18:57 --> Severity: Notice --> Trying to get property 'privileges' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 50
ERROR - 2021-10-28 03:00:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 03:05:20 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:35:20 --> Severity: Notice --> Trying to get property 'privileges' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 52
ERROR - 2021-10-28 03:05:25 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:35:25 --> Severity: Notice --> Trying to get property 'privileges' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 52
ERROR - 2021-10-28 03:19:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:49:16 --> Severity: error --> Exception: Call to undefined function updateApiToken() X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Login.php 77
ERROR - 2021-10-28 03:19:44 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:49:44 --> Severity: error --> Exception: Call to undefined function updateApiToken() X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Login.php 77
ERROR - 2021-10-28 03:20:12 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:50:12 --> Severity: error --> Exception: Call to undefined function update_api_token() X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Login.php 77
ERROR - 2021-10-28 03:20:20 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 03:21:17 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 03:57:29 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 03:57:30 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 03:57:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-28 03:57:30 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 03:57:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-28 03:57:37 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 03:57:40 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 03:57:46 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 03:57:46 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 03:57:55 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 04:12:43 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 07:42:43 --> Severity: error --> Exception: Call to undefined function validSession() F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 40
ERROR - 2021-10-28 04:13:14 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 07:43:14 --> Severity: Notice --> Array to string conversion F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 18
ERROR - 2021-10-28 07:43:14 --> Severity: error --> Exception: Using $this when not in object context F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 20
ERROR - 2021-10-28 04:14:18 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 07:44:19 --> Severity: Notice --> Array to string conversion F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 18
ERROR - 2021-10-28 07:44:19 --> Severity: error --> Exception: Using $this when not in object context F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 20
ERROR - 2021-10-28 04:22:38 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 07:52:38 --> Severity: Notice --> Array to string conversion F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 18
ERROR - 2021-10-28 07:52:38 --> Severity: error --> Exception: Using $this when not in object context F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 20
ERROR - 2021-10-28 04:22:57 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 07:52:57 --> Severity: Notice --> Array to string conversion F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 18
ERROR - 2021-10-28 07:52:57 --> Severity: error --> Exception: Using $this when not in object context F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 20
ERROR - 2021-10-28 04:23:21 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 07:53:21 --> Severity: Notice --> Trying to get property 'privileges' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 65
ERROR - 2021-10-28 04:23:32 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 07:53:32 --> Severity: Notice --> Array to string conversion F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 18
ERROR - 2021-10-28 07:53:32 --> Severity: error --> Exception: Using $this when not in object context F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 20
ERROR - 2021-10-28 04:28:18 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 07:58:18 --> Severity: Notice --> Array to string conversion F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 18
ERROR - 2021-10-28 07:58:18 --> Severity: error --> Exception: Using $this when not in object context F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 20
ERROR - 2021-10-28 04:29:00 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 07:59:00 --> Severity: Notice --> Array to string conversion F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 18
ERROR - 2021-10-28 07:59:00 --> Severity: error --> Exception: Using $this when not in object context F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 20
ERROR - 2021-10-28 04:30:13 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:00:13 --> Severity: Notice --> Array to string conversion F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 18
ERROR - 2021-10-28 08:00:13 --> Severity: error --> Exception: Using $this when not in object context F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 20
ERROR - 2021-10-28 04:30:49 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:00:49 --> Severity: Notice --> Array to string conversion F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 18
ERROR - 2021-10-28 08:00:49 --> Severity: error --> Exception: Using $this when not in object context F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 20
ERROR - 2021-10-28 04:32:12 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:02:12 --> Severity: Notice --> Array to string conversion F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 18
ERROR - 2021-10-28 08:02:12 --> Severity: error --> Exception: Using $this when not in object context F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 20
ERROR - 2021-10-28 04:33:33 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:03:33 --> Severity: Notice --> Array to string conversion F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 18
ERROR - 2021-10-28 08:03:33 --> Severity: error --> Exception: Using $this when not in object context F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 20
ERROR - 2021-10-28 04:34:07 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:04:07 --> Severity: Notice --> Array to string conversion F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 18
ERROR - 2021-10-28 08:04:07 --> Severity: error --> Exception: Using $this when not in object context F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 20
ERROR - 2021-10-28 04:35:11 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 04:35:27 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 04:35:59 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:05:59 --> Severity: error --> Exception: Using $this when not in object context F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 20
ERROR - 2021-10-28 04:36:11 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:06:11 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$id F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 20
ERROR - 2021-10-28 08:06:11 --> Severity: Notice --> Trying to get property 'privileges' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 65
ERROR - 2021-10-28 04:36:37 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:06:37 --> Severity: Notice --> Trying to get property 'id' of non-object F:\xampp\htdocs\rph-mobile\application\helpers\api_helper.php 21
ERROR - 2021-10-28 08:06:37 --> Severity: Notice --> Trying to get property 'privileges' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 65
ERROR - 2021-10-28 04:36:44 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:06:44 --> Severity: Notice --> Trying to get property 'privileges' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 65
ERROR - 2021-10-28 04:37:07 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 04:37:32 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 04:38:21 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 04:38:30 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:08:30 --> Severity: Notice --> Trying to get property 'privileges' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 62
ERROR - 2021-10-28 04:39:02 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 04:39:08 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 04:57:16 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:00:16 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:30:16 --> Severity: Notice --> Trying to get property 'privileges' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 50
ERROR - 2021-10-28 05:09:10 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:09:11 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:09:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-28 05:11:05 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:41:05 --> Severity: Notice --> Trying to get property 'privileges' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 52
ERROR - 2021-10-28 05:11:17 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:41:17 --> Severity: Notice --> Trying to get property 'privileges' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 58
ERROR - 2021-10-28 05:11:33 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:12:05 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:12:23 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:12:44 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:13:01 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:43:01 --> Severity: Notice --> Trying to get property 'privileges' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 58
ERROR - 2021-10-28 05:13:43 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:16:50 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:17:19 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:47:20 --> Severity: Notice --> Undefined property: Sales_report::$user_model F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 27
ERROR - 2021-10-28 08:47:20 --> Severity: error --> Exception: Call to a member function getUserDetails() on null F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 27
ERROR - 2021-10-28 05:17:31 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:18:50 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:19:23 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:49:23 --> Severity: Notice --> Trying to get property 'privileges' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 62
ERROR - 2021-10-28 05:19:31 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:49:31 --> Severity: Notice --> Trying to get property 'privileges' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 63
ERROR - 2021-10-28 05:19:41 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:49:41 --> Severity: Notice --> Trying to get property 'privileges' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 63
ERROR - 2021-10-28 05:19:59 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:20:12 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:20:16 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:20:44 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:21:01 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:21:07 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:25:29 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:55:30 --> Severity: error --> Exception: Call to private method API_Controller::_isAuthorized() from context 'Projects' F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Projects.php 33
ERROR - 2021-10-28 05:25:41 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:25:50 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:55:50 --> Severity: error --> Exception: Call to private method API_Controller::_isAuthorized() from context 'Projects' F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Projects.php 33
ERROR - 2021-10-28 05:27:47 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:57:47 --> Severity: error --> Exception: Call to private method API_Controller::_isAuthorized() from context 'Projects' F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Projects.php 37
ERROR - 2021-10-28 05:27:52 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:28:04 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 08:58:04 --> Severity: 4096 --> Object of class stdClass could not be converted to string F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Projects.php 30
ERROR - 2021-10-28 05:28:31 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:33:54 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:38:34 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:43:05 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:43:05 --> Severity: error --> Exception: syntax error, unexpected 'die' (T_EXIT) F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 52
ERROR - 2021-10-28 05:43:13 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 09:13:13 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 490
ERROR - 2021-10-28 05:43:40 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 09:13:40 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 488
ERROR - 2021-10-28 05:44:02 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 09:14:02 --> Severity: 4096 --> Object of class stdClass could not be converted to string F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 488
ERROR - 2021-10-28 05:44:18 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:44:33 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 09:14:33 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 488
ERROR - 2021-10-28 05:44:50 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:45:04 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 09:15:04 --> Severity: Notice --> Trying to get property 'email' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 490
ERROR - 2021-10-28 09:15:04 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 490
ERROR - 2021-10-28 05:45:32 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 09:15:32 --> Severity: Notice --> Trying to get property 'email' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\Bims.php 38
ERROR - 2021-10-28 09:15:32 --> Severity: Notice --> Trying to get property 'group_id' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\Bims.php 38
ERROR - 2021-10-28 09:15:32 --> Severity: Notice --> Trying to get property 'company_id' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\Bims.php 38
ERROR - 2021-10-28 09:15:32 --> Severity: Notice --> Trying to get property 'firstname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 68
ERROR - 2021-10-28 09:15:32 --> Severity: Notice --> Trying to get property 'lastname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 69
ERROR - 2021-10-28 09:15:32 --> Severity: Notice --> Trying to get property 'firstname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 82
ERROR - 2021-10-28 09:15:32 --> Severity: Notice --> Trying to get property 'lastname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 82
ERROR - 2021-10-28 09:15:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at F:\xampp\htdocs\rph-mobile\system\core\Exceptions.php:271) F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 538
ERROR - 2021-10-28 09:15:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at F:\xampp\htdocs\rph-mobile\system\core\Exceptions.php:271) F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 539
ERROR - 2021-10-28 05:46:04 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 09:16:04 --> Severity: Notice --> Trying to get property 'email' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\Bims.php 38
ERROR - 2021-10-28 09:16:04 --> Severity: Notice --> Trying to get property 'group_id' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\Bims.php 38
ERROR - 2021-10-28 09:16:04 --> Severity: Notice --> Trying to get property 'company_id' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\Bims.php 38
ERROR - 2021-10-28 09:16:04 --> Severity: Notice --> Trying to get property 'firstname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 68
ERROR - 2021-10-28 09:16:04 --> Severity: Notice --> Trying to get property 'lastname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 69
ERROR - 2021-10-28 09:16:04 --> Severity: Notice --> Trying to get property 'firstname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 82
ERROR - 2021-10-28 09:16:04 --> Severity: Notice --> Trying to get property 'lastname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 82
ERROR - 2021-10-28 09:16:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at F:\xampp\htdocs\rph-mobile\system\core\Exceptions.php:271) F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 538
ERROR - 2021-10-28 09:16:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at F:\xampp\htdocs\rph-mobile\system\core\Exceptions.php:271) F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 539
ERROR - 2021-10-28 05:46:59 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 09:16:59 --> Severity: Notice --> Trying to get property 'email' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\Bims.php 38
ERROR - 2021-10-28 09:16:59 --> Severity: Notice --> Trying to get property 'group_id' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\Bims.php 38
ERROR - 2021-10-28 09:16:59 --> Severity: Notice --> Trying to get property 'company_id' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\Bims.php 38
ERROR - 2021-10-28 09:16:59 --> Severity: Notice --> Trying to get property 'firstname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 68
ERROR - 2021-10-28 09:16:59 --> Severity: Notice --> Trying to get property 'lastname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 69
ERROR - 2021-10-28 09:16:59 --> Severity: Notice --> Trying to get property 'firstname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 82
ERROR - 2021-10-28 09:16:59 --> Severity: Notice --> Trying to get property 'lastname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 82
ERROR - 2021-10-28 09:16:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at F:\xampp\htdocs\rph-mobile\system\core\Exceptions.php:271) F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 538
ERROR - 2021-10-28 09:16:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at F:\xampp\htdocs\rph-mobile\system\core\Exceptions.php:271) F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 539
ERROR - 2021-10-28 05:49:28 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:49:32 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 09:19:32 --> Severity: Notice --> Trying to get property 'email' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\Bims.php 38
ERROR - 2021-10-28 09:19:32 --> Severity: Notice --> Trying to get property 'group_id' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\Bims.php 38
ERROR - 2021-10-28 09:19:32 --> Severity: Notice --> Trying to get property 'company_id' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\Bims.php 38
ERROR - 2021-10-28 09:19:32 --> Severity: Notice --> Trying to get property 'firstname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 68
ERROR - 2021-10-28 09:19:32 --> Severity: Notice --> Trying to get property 'lastname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 69
ERROR - 2021-10-28 09:19:32 --> Severity: Notice --> Trying to get property 'firstname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 82
ERROR - 2021-10-28 09:19:32 --> Severity: Notice --> Trying to get property 'lastname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 82
ERROR - 2021-10-28 09:19:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at F:\xampp\htdocs\rph-mobile\system\core\Exceptions.php:271) F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 538
ERROR - 2021-10-28 09:19:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at F:\xampp\htdocs\rph-mobile\system\core\Exceptions.php:271) F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 539
ERROR - 2021-10-28 05:49:33 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:49:36 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 09:19:36 --> Severity: Notice --> Trying to get property 'email' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\Bims.php 38
ERROR - 2021-10-28 09:19:36 --> Severity: Notice --> Trying to get property 'group_id' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\Bims.php 38
ERROR - 2021-10-28 09:19:36 --> Severity: Notice --> Trying to get property 'company_id' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\Bims.php 38
ERROR - 2021-10-28 09:19:36 --> Severity: Notice --> Trying to get property 'firstname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 68
ERROR - 2021-10-28 09:19:36 --> Severity: Notice --> Trying to get property 'lastname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 69
ERROR - 2021-10-28 09:19:36 --> Severity: Notice --> Trying to get property 'firstname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 82
ERROR - 2021-10-28 09:19:36 --> Severity: Notice --> Trying to get property 'lastname' of non-object F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Login.php 82
ERROR - 2021-10-28 09:19:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at F:\xampp\htdocs\rph-mobile\system\core\Exceptions.php:271) F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 538
ERROR - 2021-10-28 09:19:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at F:\xampp\htdocs\rph-mobile\system\core\Exceptions.php:271) F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 539
ERROR - 2021-10-28 05:50:10 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:51:10 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 09:21:10 --> Severity: Notice --> Trying to get property 'email' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 490
ERROR - 2021-10-28 09:21:10 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 490
ERROR - 2021-10-28 05:51:15 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 09:21:15 --> Severity: Notice --> Trying to get property 'email' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 490
ERROR - 2021-10-28 09:21:15 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 490
ERROR - 2021-10-28 05:51:28 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:52:26 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:52:36 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:52:41 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:53:04 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 09:23:04 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 490
ERROR - 2021-10-28 05:53:19 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 05:53:33 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:25:34 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:26:46 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:27:18 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 09:57:19 --> Severity: Notice --> Array to string conversion F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 41
ERROR - 2021-10-28 06:27:34 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:27:43 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:27:47 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 09:57:47 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 490
ERROR - 2021-10-28 06:28:01 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 09:58:01 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 490
ERROR - 2021-10-28 06:28:18 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:28:26 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 09:58:26 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 490
ERROR - 2021-10-28 06:28:32 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:29:16 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:29:16 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:29:17 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:29:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-28 06:29:17 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:29:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-28 06:29:21 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:30:11 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:30:45 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:30:47 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:30:49 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:30:49 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:30:49 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:30:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-28 06:30:54 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:32:31 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:33:49 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:34:35 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:35:07 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:35:11 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:36:55 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 10:06:56 --> Severity: Notice --> Trying to get property 'id' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 490
ERROR - 2021-10-28 10:06:56 --> Severity: Notice --> Trying to get property 'email' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 491
ERROR - 2021-10-28 10:06:56 --> Severity: Notice --> Trying to get property 'piid' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 492
ERROR - 2021-10-28 10:06:56 --> Severity: Notice --> Trying to get property 'phone' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 493
ERROR - 2021-10-28 06:37:32 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:38:58 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:39:33 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 10:09:33 --> Severity: Notice --> Undefined index: id F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 42
ERROR - 2021-10-28 06:39:48 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:40:27 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:40:35 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:40:38 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 10:10:38 --> Severity: Notice --> Trying to get property 'id' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 490
ERROR - 2021-10-28 10:10:38 --> Severity: Notice --> Trying to get property 'email' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 491
ERROR - 2021-10-28 06:41:03 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:41:26 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:42:43 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:42:52 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:43:01 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:44:39 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:44:53 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:45:06 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:46:00 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:46:04 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:46:12 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:46:21 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:46:30 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:46:38 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:46:50 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:46:56 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:47:07 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:47:14 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:47:28 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:47:59 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:48:03 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:48:18 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:48:37 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:48:53 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:49:15 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:49:31 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:49:37 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:49:56 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:50:12 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:50:15 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:50:23 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:50:28 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:50:33 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:50:41 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 10:20:41 --> Severity: Notice --> Trying to get property 'id' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 490
ERROR - 2021-10-28 10:20:41 --> Severity: Notice --> Trying to get property 'email' of non-object F:\xampp\htdocs\rph-mobile\application\libraries\API_Controller.php 491
ERROR - 2021-10-28 06:57:54 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 10:27:54 --> Severity: Notice --> Undefined index: id F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 47
ERROR - 2021-10-28 06:59:29 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 10:29:29 --> Severity: Notice --> Undefined index: id F:\xampp\htdocs\rph-mobile\application\controllers\api\v1\Sales_report.php 40
ERROR - 2021-10-28 06:59:39 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 06:59:56 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 07:01:26 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
ERROR - 2021-10-28 07:01:31 --> $config['composer_autoload'] is set to TRUE but F:\xampp\htdocs\rph-mobile\application\vendor/autoload.php was not found.
