<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-24 05:29:09 --> Severity: error --> Exception: Call to undefined method Login::_apiConfig() X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Login.php 33
ERROR - 2021-10-24 05:29:33 --> Severity: error --> Exception: Call to undefined method Login::_apiConfig() X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Login.php 34
ERROR - 2021-10-24 03:18:16 --> Severity: Notice --> Undefined variable: return X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Login.php 80
ERROR - 2021-10-24 03:18:16 --> Severity: Notice --> Undefined variable: return_http X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Login.php 80
ERROR - 2021-10-24 03:18:16 --> Severity: Notice --> Undefined index:  X:\xampp\htdocs\rcd\rph-admin\application\libraries\API_Controller.php 531
ERROR - 2021-10-24 03:18:50 --> Severity: Notice --> Undefined variable: return X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Login.php 83
ERROR - 2021-10-24 03:18:50 --> Severity: Notice --> Undefined variable: return_http X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Login.php 83
ERROR - 2021-10-24 03:18:50 --> Severity: Notice --> Undefined index:  X:\xampp\htdocs\rcd\rph-admin\application\libraries\API_Controller.php 531
ERROR - 2021-10-24 03:20:19 --> Query error: Column 'company_id' cannot be null - Invalid query: INSERT INTO `activity_log` (`user_id`, `company_id`, `module`, `event`, `ipaddress`, `log_description`) VALUES ('7', NULL, 'Mobile App - Login', 'Login', '127.0.0.1', 'Jayson logged in to the mobile app')
ERROR - 2021-10-24 03:21:51 --> Query error: Column 'company_id' cannot be null - Invalid query: INSERT INTO `activity_log` (`user_id`, `company_id`, `module`, `event`, `ipaddress`, `log_description`) VALUES ('7', NULL, 'Mobile App - Login', 'Login', '127.0.0.1', 'Jayson logged in to the mobile app')
ERROR - 2021-10-24 03:24:52 --> Severity: Notice --> Undefined property: stdClass::$createdDateTime X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Login.php 69
