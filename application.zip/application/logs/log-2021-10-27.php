<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-27 01:40:29 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 01:40:30 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 01:40:30 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 01:40:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-27 01:40:30 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 01:40:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-27 01:40:37 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 01:40:39 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 01:40:43 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 01:40:44 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 02:30:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 02:30:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:26:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:30:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:31:05 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:34:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:35:27 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:35:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:36:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:40:46 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:10:46 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Positions.php 46
ERROR - 2021-10-27 10:10:46 --> Severity: Notice --> Trying to get property 'position' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Positions.php 47
ERROR - 2021-10-27 06:41:18 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:11:18 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Positions.php 46
ERROR - 2021-10-27 10:11:18 --> Severity: Notice --> Trying to get property 'position' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Positions.php 47
ERROR - 2021-10-27 06:41:45 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:11:45 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Positions.php 46
ERROR - 2021-10-27 10:11:45 --> Severity: Notice --> Trying to get property 'position' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Positions.php 47
ERROR - 2021-10-27 06:42:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:45:08 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:54:26 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:54:29 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:54:33 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:54:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:54:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:54:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:54:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-27 06:54:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:54:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-27 06:57:40 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:57:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:57:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:57:58 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:57:58 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 06:58:12 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:06:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:06:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:06:58 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:07:02 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:07:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:07:10 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:12:20 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:12:51 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:12:51 --> 404 Page Not Found: api/v1/Divisions/1
ERROR - 2021-10-27 08:14:20 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:14:20 --> 404 Page Not Found: api/v1/Divisions/1
ERROR - 2021-10-27 08:14:34 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:14:44 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:14:50 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:16:30 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:16:30 --> 404 Page Not Found: api/v1/Developers/1
ERROR - 2021-10-27 08:17:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:19:09 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:19:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:19:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:20:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:20:52 --> 404 Page Not Found: api/v1/Projects/index
ERROR - 2021-10-27 08:24:33 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:25:17 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 11:55:17 --> Severity: Notice --> Undefined property: stdClass::$developer X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 90
ERROR - 2021-10-27 08:25:50 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:25:55 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:25:58 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:26:03 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:26:14 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:27:39 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:44:24 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:44:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:45:31 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:47:38 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:47:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'id' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 138
ERROR - 2021-10-27 12:17:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 139
ERROR - 2021-10-27 12:17:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at X:\xampp\htdocs\rcd\rph-admin\system\core\Exceptions.php:271) X:\xampp\htdocs\rcd\rph-admin\application\libraries\API_Controller.php 530
ERROR - 2021-10-27 12:17:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at X:\xampp\htdocs\rcd\rph-admin\system\core\Exceptions.php:271) X:\xampp\htdocs\rcd\rph-admin\application\libraries\API_Controller.php 531
ERROR - 2021-10-27 08:48:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:48:13 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:48:18 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:48:33 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:48:37 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:48:44 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:50:14 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:20:14 --> Severity: Notice --> Undefined variable: id X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Projects.php 135
ERROR - 2021-10-27 08:50:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:50:27 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:50:43 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:50:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 08:51:13 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 09:33:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:21:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:21:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:21:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:37:43 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:37:43 --> 404 Page Not Found: api/v1/Sales_reports/get
ERROR - 2021-10-27 10:38:38 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:38:38 --> 404 Page Not Found: api/v1/Sales_reports/get_pending
ERROR - 2021-10-27 10:40:23 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 14:10:23 --> Severity: Notice --> Undefined property: Sales_report::$user_model X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 41
ERROR - 2021-10-27 14:10:23 --> Severity: error --> Exception: Call to a member function getUserDetails() on null X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 41
ERROR - 2021-10-27 10:40:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Undefined variable: gl X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Trying to get property 'reservation_date' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Undefined variable: gl X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Trying to get property 'reservation_date' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Undefined variable: gl X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Trying to get property 'reservation_date' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Undefined variable: gl X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Trying to get property 'reservation_date' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Undefined variable: gl X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Trying to get property 'reservation_date' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Undefined variable: gl X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Trying to get property 'reservation_date' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Undefined variable: gl X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Trying to get property 'reservation_date' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Undefined variable: gl X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Trying to get property 'reservation_date' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Undefined variable: gl X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Trying to get property 'reservation_date' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Undefined variable: gl X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Trying to get property 'reservation_date' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Undefined variable: gl X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Trying to get property 'reservation_date' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Undefined variable: gl X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Trying to get property 'reservation_date' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Undefined variable: gl X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Trying to get property 'reservation_date' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Undefined variable: gl X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Trying to get property 'reservation_date' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Undefined variable: gl X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Trying to get property 'reservation_date' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Undefined variable: gl X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Notice --> Trying to get property 'reservation_date' of non-object X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 60
ERROR - 2021-10-27 14:10:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at X:\xampp\htdocs\rcd\rph-admin\system\core\Exceptions.php:271) X:\xampp\htdocs\rcd\rph-admin\application\libraries\API_Controller.php 530
ERROR - 2021-10-27 14:10:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at X:\xampp\htdocs\rcd\rph-admin\system\core\Exceptions.php:271) X:\xampp\htdocs\rcd\rph-admin\application\libraries\API_Controller.php 531
ERROR - 2021-10-27 10:40:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:41:07 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:41:08 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:42:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:42:28 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:42:48 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:43:01 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:44:48 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:45:27 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:45:40 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 10:45:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 11:50:31 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 11:50:36 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 11:57:19 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 11:57:20 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:09:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:09:17 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:11:17 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:11:24 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:11:30 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:11:39 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:12:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:12:10 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:12:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:12:32 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:12:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:13:11 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:14:49 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:14:56 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:14:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:15:31 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:22:36 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:33:56 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:38:29 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 16:08:29 --> Severity: Notice --> Undefined offset: 1 X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 110
ERROR - 2021-10-27 12:39:29 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 16:09:29 --> Severity: Notice --> Undefined offset: 1 X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 112
ERROR - 2021-10-27 12:39:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:41:36 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:41:53 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:41:53 --> 404 Page Not Found: api/v1/Sales_reports/search
ERROR - 2021-10-27 12:42:07 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:42:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:44:43 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:45:05 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:48:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:48:36 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 12:54:51 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:00:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:00:15 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:00:21 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:01:02 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:01:11 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:04:38 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:04:58 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:05:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:05:19 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:05:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:06:08 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:06:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:06:29 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:06:32 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:06:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:06:48 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:06:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:07:12 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:08:30 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:08:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:09:07 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:09:25 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:14:24 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 16:44:24 --> Severity: error --> Exception: Too few arguments to function Sales_report::get(), 1 passed in X:\xampp\htdocs\rcd\rph-admin\system\core\CodeIgniter.php on line 532 and exactly 2 expected X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 30
ERROR - 2021-10-27 13:14:46 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 16:44:46 --> Severity: error --> Exception: Too few arguments to function Sales_report::get(), 1 passed in X:\xampp\htdocs\rcd\rph-admin\system\core\CodeIgniter.php on line 532 and exactly 2 expected X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 30
ERROR - 2021-10-27 13:14:50 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 16:44:50 --> Severity: Notice --> Undefined variable: limit X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 56
ERROR - 2021-10-27 13:15:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:17:18 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:17:34 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:18:09 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:18:24 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:18:28 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:18:39 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:18:39 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF), expecting ']' X:\xampp\htdocs\rcd\rph-admin\application\controllers\api\v1\Sales_report.php 76
ERROR - 2021-10-27 13:19:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:20:01 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:20:10 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:21:11 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:21:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:21:27 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:21:36 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:21:43 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:22:20 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:23:11 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:23:20 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:23:32 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:23:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:24:37 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:24:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:25:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:25:20 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:25:34 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:25:52 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:25:52 --> 404 Page Not Found: api/v1/Sales_reports/pending
ERROR - 2021-10-27 13:25:58 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:26:19 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:26:31 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:26:37 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:26:40 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 16:56:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-2, 2' at line 11 - Invalid query: SELECT `A`.*, CONCAT(B.`firstname`, ' ', B.`lastname`) as createdBy, CONCAT(C.`firstname`, ' ', C.`lastname`) as modifiedBy, CONCAT(D.`firstname`, ' ', D.`lastname`) as approvedBy, `E`.`developer`, `F`.`project_name` as `name_of_project`, `E`.`id` as `developer_id`, `F`.`id` as `project_id`
FROM `sales_report` `A`
LEFT OUTER JOIN `users` `B` ON `B`.`id` = `A`.`prepared_by`
LEFT OUTER JOIN `users` `C` ON `C`.`id` = `A`.`lastModifiedBy`
LEFT OUTER JOIN `users` `D` ON `D`.`id` = `A`.`approvedBy`
LEFT OUTER JOIN `developers` `E` ON `E`.`id` = `A`.`developer`
LEFT OUTER JOIN `projects` `F` ON `F`.`id` = `A`.`name_of_project`
WHERE `A`.`sr_status` = 0
AND `A`.`nStatus` = 1
ORDER BY `A`.`id` DESC
 LIMIT -2, 2
ERROR - 2021-10-27 13:26:51 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:27:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:27:04 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:27:08 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:27:28 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:27:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:28:24 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:28:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:28:45 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:29:20 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:32:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:52:11 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:52:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:52:20 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:52:24 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:52:39 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:52:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:53:16 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:53:23 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:53:41 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:53:41 --> 404 Page Not Found: api/v1/Sales_reports/approved
ERROR - 2021-10-27 13:54:02 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:54:12 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:54:12 --> 404 Page Not Found: api/v1/Sales_reports/approved
ERROR - 2021-10-27 13:54:43 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:54:43 --> 404 Page Not Found: api/v1/Sales_reports/approved
ERROR - 2021-10-27 13:54:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:55:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:55:17 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:55:23 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 13:55:28 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 14:00:41 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-27 15:55:15 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
