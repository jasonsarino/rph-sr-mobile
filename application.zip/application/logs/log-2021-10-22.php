<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-22 06:26:20 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 06:26:21 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 06:26:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-22 06:26:21 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 06:26:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-22 06:26:28 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 06:26:31 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 06:26:37 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 06:26:40 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 06:26:40 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 06:26:51 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 06:26:53 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 06:26:54 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 06:26:55 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 06:27:00 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 06:29:38 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 09:37:05 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 09:37:05 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 09:37:05 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 09:37:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-22 09:37:06 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 09:37:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-22 11:49:22 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 11:49:24 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 11:50:29 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 11:50:40 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 11:50:50 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 11:50:53 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 11:51:17 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 11:51:26 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 11:51:30 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 11:51:44 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 13:11:46 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 13:59:37 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:25:23 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:25:24 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:25:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 15:28:40 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:28:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:28:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-22 15:28:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:28:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 15:28:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:28:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:28:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-10-22 15:28:47 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:33:57 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:37:09 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:37:17 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:37:44 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:38:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:38:40 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:39:12 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:41:12 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:41:35 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:46:21 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:46:23 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:48:48 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:49:01 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:49:56 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:50:09 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:50:15 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:50:20 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:50:25 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:50:42 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
ERROR - 2021-10-22 15:50:51 --> $config['composer_autoload'] is set to TRUE but X:\xampp\htdocs\rcd\rph-admin\application\vendor/autoload.php was not found.
